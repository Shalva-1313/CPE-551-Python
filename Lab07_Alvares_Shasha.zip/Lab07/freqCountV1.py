# Author: Shasha Alvares
# Date: 3/13/25
# Description: Count the number of words in some input text
import os

def main():
    my_dict = {} #create empty dictionary
    readTextFile(my_dict)
    outputFreq(my_dict)

def readTextFile(my_dict: dict):
#keep prompting the user until they enter a file that exists
    while True:
        userFile = input("Please enter the name of the file to analyze: ")
        if os.path.exists(userFile):
            break
        else:
            print(f"{userFile} does not exist! \n")

    #given the dictionary file exists
    with(open(userFile, "r") as myFile):
        for line in myFile:
            # changes letters to lowercase, strip extra spaces, and store each word in the list individually
            line = line.lower().strip().split(" ")
            #iterate through the list of words
            for word in line:
                if word not in my_dict:
                    my_dict[word] = 1 #add the word to my_dict
                else: #word exists in dict so increase the key value by 1
                    my_dict[word] += 1

def outputFreq(my_dict: dict):
    print(f"The file contained {len(my_dict)} unique words.\n")
    for word, count in my_dict.items():
        print(f"{word}:{count}")

if __name__ == "__main__":
    main()



