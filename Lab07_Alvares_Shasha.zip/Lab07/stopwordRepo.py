# Author: Shasha Alvares
# Date: 3/13/25
# Description: Program acts as a repository for stopwords
import pickle
import os
PICKLINGNAME = "stopwordset.data"

def main():
    if os.path.exists(PICKLINGNAME):
        x = restoreStopWords()    #if stopwords file exists load the set
    else:
        x = set()               #if stopwords file does not exist start with an empty set

    keepGoing = True
    print("Welcome to the stopword repository!")
    while keepGoing:
        print("\nPlease choose from the following options:"
              "\n\t1. Add a new list of stopwords"
              "\n\t2. Write current set of stopwords to a file"
              "\n\t3. Display current set of stopwords"
              "\n\t4. Quit\n")
        userChoice = int(input("Please enter your choice: "))

        if userChoice == 1:
            readStopWordsFile(x)
        elif userChoice == 2:
            writeStopWordsFile(x)
        elif userChoice == 3:
            displayStopWords(x)
        else: #userChoice == 4
            print("Thank you for using stopword repository!")
            storeStopWords(x)
            keepGoing = False

def readStopWordsFile(my_set: set):
    """
    :param my_set: empty set
    :return: nothing
    """
    # keep prompting the user until they enter a file that exists
    while True:
        sWF = input("Please enter the name of the new stopwords the file: ")
        if os.path.exists(sWF):
            break
        else:
            print(f"{sWF} does not exist! \n")

    #given the sWF file exists
    with(open(sWF, "r") as myFile):
        for line in myFile:
            # changes letters to lowercase, strip extra spaces, and store each word in the list individually
            line = line.lower().strip().split(" ")
            #iterate through the list of words
            for word in line:
                if word not in my_set: #word needs to be added to my_set
                    my_set.add(word) #add the word to my_set as a list
                else: #word already in set
                    print(f"We already have the word: {word}")

def writeStopWordsFile(my_set: set):
    """
    :param my_set:
    :return: nothing
    """
    newFileName = input("Please enter the name of the stopwords file to write to: ")
    outFile = open(newFileName, "w")
    for line in my_set:
        outFile.write(line + "\n")
    outFile.close()

def displayStopWords(my_set: set):
    """
    :param my_set:
    :return: nothing
    """
    print(f"Currently we have {len(my_set)} stopwords: ")
    for word in my_set:
        print(word)

def storeStopWords(my_set: set):
    """
    :param my_set:
    :return: nothing
    """
    outFile = open(PICKLINGNAME, "wb")
    pickle.dump(my_set, outFile)
    outFile.close()

def restoreStopWords():
    """
    :return: variable containing the Set of stopwords
    """
    inFile = open(PICKLINGNAME, "rb")
    data = pickle.load(inFile)
    inFile.close()
    return data

if __name__ == "__main__":
    main()