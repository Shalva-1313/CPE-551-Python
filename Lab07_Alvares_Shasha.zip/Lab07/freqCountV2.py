# Author: Shasha Alvares
# Date: 3/13/25
# Description: Improve freqCountV1 by counting the words in the text, excluding stop words
import os

def main():
    my_dict = {} #create empty dictionary
    my_set = set([]) #create empty set that will store words in a list
    readStopWordsFile(my_set)
    readTextFile(my_dict, my_set)
    outputFreq(my_dict)

def readTextFile(my_dict: dict, my_set: set):
    """
    :param my_dict: dictionary of words from the txt file
    :param my_set: set of stopwords
    :return: nothing but adds words not in set to the dictionary
    """
#keep prompting the user until they enter a file that exists
    while True:
        userFile = input("Please enter the name of the file to analyze: ")
        if os.path.exists(userFile):
            break
        else:
            print(f"{userFile} does not exist! \n")

    #given the dictionary file exists
    with(open(userFile, "r") as myFile):
        for line in myFile:
            # changes letters to lowercase, strip extra spaces, and store each word in the list individually
            line = line.lower().strip().split(" ")
            #iterate through the list of words
            for word in line:
                if word not in my_set: #if word not in sWF set add it to the dict
                    #if word not in dict returns 0, otherwise returns the value and adds 1 to it
                    my_dict[word] = my_dict.get(word, 0) + 1

def outputFreq(my_dict: dict):
    """
    :param my_dict:
    :return: nothing
    """
    print(f"The file contained {len(my_dict)} unique words.\n")
    for word, count in my_dict.items():
        print(f"{word}:{count}")

def readStopWordsFile(my_set: set):
    """
    :param my_set: empty set
    :return: nothing
    """
    # keep prompting the user until they enter a file that exists
    while True:
        sWF = input("Please enter the name of the stopwords the file: ")
        if os.path.exists(sWF):
            break
        else:
            print(f"{sWF} does not exist! \n")

    #given the sWF file exists
    with(open(sWF, "r") as myFile):
        for line in myFile:
            # changes letters to lowercase, strip extra spaces, and store each word in the list individually
            line = line.lower().strip().split(" ")
            #iterate through the list of words
            for word in line:
                if word not in my_set: #word needs to be added to my_set
                    my_set.add(word) #add the word to my_set as a list

if __name__ == "__main__":
    main()