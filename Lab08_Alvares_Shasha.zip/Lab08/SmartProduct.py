# Author: Shasha Alvares
# Date: 4/1/25
# Description: Updated version my Product.py file

class SmartProduct:
    def __init__(self, id=0,name="", units=0, price=9.99, cost=0):
        self.__idNum = id
        self.__prodName = name
        self.__unitsToOrder = units
        self.__singleUnitPrice = price
        #calculates total cost based on # units ordered and price per unit
        self.__totalCost = self.__unitsToOrder * self.__singleUnitPrice

    def getProdName(self):
        return self.__prodName

    def setProdName(self, name):
        self.__prodName = name

    def getUnitsToOrder(self):
        return self.__unitsToOrder

    def setUnitsToOrder(self, order):
        self.__unitsToOrder = order

    def getSingleUnitPrice(self):
        return self.__singleUnitPrice

    def setSingleUnitPrice(self, singlePrice):
        self.__singleUnitPrice = singlePrice

    def getTotalCost(self):
        return self.__totalCost

    def setTotalCost(self, cost):
        self.__totalCost = cost

    def getIdNum(self):
        return self.__idNum

    def setIdNum(self, id):
        self.__idNum = id

