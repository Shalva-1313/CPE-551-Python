# Author: Shasha Alvares
# Date: 4/1/25
# Description: Updated version my orderSystem.py file

import SmartProduct

def calcTotal(productList):
    total = 0
    for prod in productList:
        total += prod.getTotalCost()
    return total

def main():

    #empty variable to store list of SmartProducts
    smartProdList = []
    numToOrder = int(input("How many products would you like to order: "))

    for x in range(numToOrder):
        prodName = input("Please enter the name of the product you wish to order: ")
        unitsToOrder = int(input("Please enter the number of units of product you wish to order: "))
        print()

        #create product object
        product = SmartProduct.SmartProduct(x + 1, prodName, unitsToOrder, 9.99)

        #calculate total cost
        total = product.getUnitsToOrder() * product.getSingleUnitPrice()
        #update total cost
        product.setTotalCost(total)
        #store product in a list
        smartProdList.append(product)

    print("\nYou ordered:")
    for product in smartProdList:
        print("ID:", product.getIdNum())
        print("Name:", product.getProdName())
        print("Units:", product.getUnitsToOrder())
        print(f"Price: ${product.getSingleUnitPrice():.2f}")
        print(f"Total Cost: ${product.getTotalCost():.2f}")
        print()

    overallTotal = calcTotal(smartProdList)
    print(f"The total cost of your order is: ${overallTotal:.2f}")


#run program
if __name__ == "__main__":
    main()



