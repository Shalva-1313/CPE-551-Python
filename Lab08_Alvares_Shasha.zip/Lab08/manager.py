# Author: Shasha Alvares
# Date: 4/1/25
# Description: Main function that runs the class Warehouse and output menu to user

import Warehouse

def main():
    w1 = Warehouse.Warehouse(0)
    keepGoing = True

    while keepGoing:
        userChoice = int(input(("Please select from the following options: " +
              "\n\t1: Add Goods" +
              "\n\t2: Remove Goods" +
              "\n\t3: Output Total Goods" +
              "\n\t4: Quit" +
              "\n\tChoice: ")))
        if userChoice == 1:
            w1.addGoods()
        elif userChoice == 2:
            w1.removeGoods()
        elif userChoice == 3:
            print(f"There are {str(w1.getTotalGoods())} goods in the warehouse.")
        elif userChoice == 4:
            print("Good bye!")
            keepGoing = False
        else:
            continue

if __name__ == "__main__":
    main()

