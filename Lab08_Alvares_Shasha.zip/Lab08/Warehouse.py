# Author: Shasha Alvares
# Date: 4/1/25
# Description: Warehouse object stores info related to the goods Warehouse

class Warehouse:
    def __init__(self, startAmount):
        self.__totalGoods = startAmount

    def getTotalGoods(self):
        return self.__totalGoods

    #addGoods and removeGoods act like the setters
    def addGoods(self):
        numToAdd = int(input("How many goods would you like to add: "))
        if numToAdd<0:
            print("You cannot add negative goods.")
        else:
            self.__totalGoods += numToAdd

    def removeGoods(self):
        numToRemove = int(input("How many goods would you like to remove: "))
        if self.getTotalGoods() - numToRemove < 0:
            print("You do not have that many goods!")
        else:
            self.__totalGoods -= numToRemove
