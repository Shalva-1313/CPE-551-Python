# Author: Shasha Alvares
# Date: 4/1/25
"""
Description: This program prompts a user for information regarding an order for a
product. Once the order is complete, the program calculates the total cost of the order and
reports that information back to the user.
"""

class Product:
    def __init__(self, name="", units=0, price=9.99, cost=0):
        self.__prodName = name
        self.__unitsToOrder = units
        self.__singleUnitPrice = price
        self.__totalCost = cost

    def getProdName(self):
        return self.__prodName

    def setProdName(self, name):
        self.__prodName = name

    def getUnitsToOrder(self):
        return self.__unitsToOrder

    def setUnitsToOrder(self, order):
        self.__unitsToOrder = order

    def getSingleUnitPrice(self):
        return self.__singleUnitPrice

    def setSingleUnitPrice(self, singlePrice):
        self.__singleUnitPrice = singlePrice

    def getTotalCost(self):
        return self.__totalCost

    def setTotalCost(self, cost):
        self.__totalCost = cost
