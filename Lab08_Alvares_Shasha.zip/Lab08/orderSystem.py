# Author: Shasha Alvares
# Date: 4/1/25
# Description: Calculate total cost of order for the Product Object and contains main which runs the program

import Product

def calcTotal(prod):
    total = prod.getSingleUnitPrice()*prod.getUnitsToOrder()
    prod.setTotalCost(total)

def main():
    p1 = Product.Product()

    #prompt user for name and set to object
    name = input("Please enter the name of the product you wish to order: ")
    p1.setProdName(name)

    # prompt user for units to order and set to object
    unitsOrdered = int(input("Please enter the number of units of product you wish to order: "))
    p1.setUnitsToOrder(unitsOrdered)

    #Calculate and set the total cost
    calcTotal(p1)

    print("You ordered: ")
    print("Name: " + p1.getProdName())
    print("Units: " + str(p1.getUnitsToOrder()))
    print("Price: $" + str(p1.getSingleUnitPrice()))
    print("Total Cost: $" + str(p1.getTotalCost()))

#run program
if __name__ == "__main__":
    main()



