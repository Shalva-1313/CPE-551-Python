# Author: Shasha Alvares
# Date: 2/13/25
# Description: Converts a user specified number in the range of 1-9, inclusively,
# into the equivalent Roman numeral according to the given table

num = input("Please enter a number between 1 and 9 to convert to a roman numeral: ")
num = int(num)

roman_Numeral = ""
if num == 1:
        roman_Numeral = "\u2160"
elif num == 2:
        roman_Numeral = "\u2161"
elif num == 3:
        roman_Numeral = "\u2162"
elif num == 4:
        roman_Numeral = "\u2163"
elif num == 5:
        roman_Numeral = "\u2164"
elif num == 6:
        roman_Numeral = "\u2165"
elif num == 7:
        roman_Numeral = "\u2166"
elif num == 8:
        roman_Numeral = "\u2167"
elif num == 9:
        roman_Numeral = "\u2168"

if num < 1 or num > 9:
    print(f"{num} is outside the allowed range of 1-9. ")
else:
    print(f"Your roman numeral is: {roman_Numeral}")

