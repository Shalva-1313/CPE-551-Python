# Author: Shasha Alvares
# Date: 2/13/25
# Description: Find the sum of all odd numbers between any two randomly
# generated numbers, the boundaries are included if they are odd.
import random

first_num = random.randint(1, 10) #generates random integer 1-10 inclusively
second_num = random.randint(11, 20) #generates random integer 11-20 inclusively
num_sum = 0

#iteratea through numbers between the two we randomly generated
for number in range(first_num, second_num+1):
    if number % 2 != 0: #verifies number is odd
        num_sum += number #adds odd number to overall sum

print(f"The first random number was {first_num}, the second random "
      f"number was {second_num}, and the sum is {num_sum}.")
