# Author: Shasha Alvares
# Date: 2/13/25
# Description: Simulate a position guessing game with the user where the user only have 3
# chances to guess the correct position before loosing

user_chances_left = 3
x_coord = 6
y_coord = 2
user_x = ""
user_y = ""

#loops continues running if user has guesses left
while user_chances_left != 0:
    user_x = int(input("What do you think its x coordinate is (1-10)? "))
    user_y = int(input("What do you think its y coordinate is (1-10)? "))

    #first check if user guessed the correct position
    if x_coord == user_x and y_coord == user_y:
        print(f"Good guess! ({x_coord },{y_coord}) was the position!")
        break

    #user guessed incorrectly, so give them a hint
    if x_coord > user_x: #user x position guess too small
        if user_chances_left != 1: #Does not print hint if this is user's last guess
            print("Bad luck! The particle's x position is greater than your x position!")
    else: ##user x position guess too large
        if user_chances_left != 1: #Does not print hint if this is user's last guess
            print("Bad luck! The particle's x position is smaller than your x position!")
    if y_coord > user_y: #user y position guess too small
        if user_chances_left != 1: #Does not print hint if this is user's last guess
            print("Bad luck! The particle's y position is greater than your x position!")
    else: ##user y position guess too large
        if user_chances_left != 1: #Does not print hint if this is user's last guess
            print("Bad luck! The particle's y position is smaller than your x position!")

    #decrease chances.
    user_chances_left -= 1
    if user_chances_left != 0:
        print(f"The particle is somewhere in this space! You have {user_chances_left} chance(s) to guess it.")

#user ran out of guesses
if user_chances_left == 0:
    print(f"No good! ({user_x},{user_y}) is outside of the range!"
          f"\nOh no! You ran out of chances. ({x_coord },{y_coord}) was the particle's position!")