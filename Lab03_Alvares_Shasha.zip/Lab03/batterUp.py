# Author: Shasha Alvares
# Date: 2/13/25
# Description: Simulate the outcome of a batter hitting a ball a random distance
# in a straight line from home base to second base

import random
#Generates a random integer between 0-450 inclusive
dist_Traveled_in_Feet = random.randint(0, 451)

if dist_Traveled_in_Feet > 400: #distance ball traveled over 400ft
    print(f"The ball flew {dist_Traveled_in_Feet} feet and the batter scored a home run! "
          "That's one point for our team!")
elif 135 <= dist_Traveled_in_Feet <= 400: #distance ball traveled between 135-400ft
    print(f"The ball flew {dist_Traveled_in_Feet} feet and the batter made it to third base!")
elif 10 <= dist_Traveled_in_Feet <= 134: #distance ball traveled between 10-134ft
    print(f"The ball flew {dist_Traveled_in_Feet} feet and the batter made it to second base!")
elif 1 <= dist_Traveled_in_Feet <= 9: #distance ball traveled between 1-9ft
    print(f"The ball flew {dist_Traveled_in_Feet} feet because the batter bunted, and "
          f"made it to first base!")
else: #distance ball traveled as 0ft
    print(f"The batter has made a strike! Oh no!")


