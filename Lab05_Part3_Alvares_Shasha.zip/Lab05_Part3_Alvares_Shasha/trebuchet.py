# Author: Shasha Alvares
# Date: 2/24/25
# Description: Record the distances the projectile flies for a number of trials,
# and keep track of the three trials with the furthest distance using Lists.

#Note the farthest distance should always be in index 0, the second farthest in index 1, and the
#third farthest in index 2
farthestDistances = [0, 0, 0]
farthestTrial = [0, 0, 0]
additionalTrial = "Y"
trialNumber = 1

while additionalTrial == "Y":
    tempDist = int(input(f"Please enter your distance for trial {trialNumber}: "))

    #new distance is greater than the farther distance
    if tempDist > farthestDistances[0]:
        #adds user distance input to first place.
        #moves previous 1st place to second and previous 2nd place to third
        farthestDistances[1], farthestDistances[2] = farthestDistances[0], farthestDistances[1]
        farthestDistances[0] = tempDist

        # adds trial number to first place.
        # moves previous 1st place to second and previous 2nd place to third
        farthestTrial[1], farthestTrial[2] = farthestTrial[0], farthestTrial[1]
        farthestTrial[0] = trialNumber

    #new distance is greater than the second farther distance but less or equal to the
    #current farthest distance
    elif tempDist > farthestDistances[1]:
        # adds user distance input to 2nd place.
        # moves previous 2nd place to 3rd
        farthestDistances[2] = farthestDistances[1]
        farthestDistances[1] = tempDist

        # adds trial number to 2nd place.
        # moves previous 2nd place to 3rd
        farthestTrial[2] = farthestTrial[1]
        farthestTrial[1] = trialNumber

    #new distance is greater than the third farthest distance but less than or equal to
    # the second farthest distance
    elif tempDist > farthestDistances[2]:
        # adds distance and trial number to 3rd place
        farthestDistances[2] = tempDist
        farthestTrial[2] = trialNumber

    userContinue = input("Would you like to input another trial? (Y/N) ")
    trialNumber += 1
    additionalTrial = userContinue

print("The top three distances for the trebuchet are: ")
print("Trial Distance: ")
print(f"\t {farthestTrial[0]} \t {farthestDistances[0]} ")
print(f"\t {farthestTrial[1]} \t {farthestDistances[1]} ")
print(f"\t {farthestTrial[2]} \t {farthestDistances[2]} ")