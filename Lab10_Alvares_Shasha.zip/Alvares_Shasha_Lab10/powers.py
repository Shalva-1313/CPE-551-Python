# Author: Shasha Alvares
# Date: 4/14/25
# Description: This program is to calculate the result of a user specified base value being put
# to a user specified exponent

def powers(base, exponent):
    print(f"powers({base}, {exponent})")

    #base case
    if exponent == 1:
        return base
    # recursive case
    else:
        return base * powers(base, exponent-1)

def main():
    basevalue = int(input("Please enter the base value: "))
    exponentvalue = int(input("Please enter the exponent value: "))
    result = powers(basevalue, exponentvalue)
    print(f"{basevalue}^{exponentvalue} is {result}")

if __name__ == "__main__":
    main()
""" Output Example

Please enter the base value: 2
Please enter the exponent value: 4
powers(2,4)
powers(2,3)
powers(2,2)
powers(2,1)
2^4 is 16
"""