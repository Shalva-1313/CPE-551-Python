# Author: Shasha Alvares
# Date: 4/14/25
# Description: Create a new version of the palindrome testing program that uses recursion

def palinTest(teststring):

    #base case
    if(len(teststring) <= 1):
        return True

    #recursive case:
    middle = len(teststring)//2 #force integer division to find the middle

    #we will check up to the middle value
    for i in range(middle):
        #compares front of string to back of string until they cross in the middle
        if teststring[0] != teststring[-1]:
            return False
        substring = teststring[1:-1]
        return palinTest(substring)

def main():
    output = input("Please enter a word to test if it is a palindrome: ")
    result = palinTest(output)
    if result == True:
        print(f"{output} is a palindrome!")
    else: #output is false
        print(f"{output} is not a palindrome!")

if __name__ == "__main__":
    main()

"""Output
Please enter a word to test if it is a palindrome: tacocat
tacocat is a palindrome!
Please enter a word to test if it is a palindrome: burritocat
burritocat is not a palindrome!
"""