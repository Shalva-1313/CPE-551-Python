# Author: Shasha Alvares
# Date: 4/14/25
# Description: This program determines if a user provided word is a palindrome using loops

def palinTest(teststring):

    #iterate through characters in string
    middle = len(teststring)//2 #force integer division to find the middle
    #we will check up to the middle value
    for i in range(middle):
        #compares front of string to back of string until they cross in the middle
        if teststring[i] != teststring[-1-i]:
            return False
    return True

def main():
    output = input("Please enter a word to test if it is a palindrome: ")
    result = palinTest(output)
    if result == True:
        print(f"{output} is a palindrome!")
    else: #output is false
        print(f"{output} is not a palindrome!")

if __name__ == "__main__":
    main()