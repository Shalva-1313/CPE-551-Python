# Author: Shasha Alvares
# Date: 4/16/25
# Description: A program that checks matching parenthesis to see if they are balanced

""" global variable to keep track of (). increment count for every ( and decrement for every
 ). If count is 0 at the end the parenthesis are balanced, otherwise it is not."""
count = 0

def parenTest(userString, pos=0):
    global count

    # Base case: we've reached the end of the string
    if pos == len(userString):
        if count == 0:
            return True
        else: #count is greater than 0
            return False

    # Recursive case
    if userString[pos] == '(':
        count += 1
    elif userString[pos] == ')':
        count -= 1
        if count < 0: #accounts for it ")" comes before "("
           return False
    return parenTest(userString, pos + 1) #recursive call to next character

def main():
    userString = input("Please enter a series of parenthesis to see if they are balanced: ")
    result = parenTest(userString)
    if result == True:
        print(f"{userString} is balanced. ")
    else: #result is False
        print(f"{userString} is not balanced. ")
if __name__ == "__main__":
    main()

"""What the output should look like :

Please enter a series of parenthesis to see if they are balanced: ()
() is balanced.
Please enter a series of parenthesis to see if they are balanced: (())
(()) is balanced.
Please enter a series of parenthesis to see if they are balanced: ()()()
()()() is balanced.
Please enter a series of parenthesis to see if they are balanced: )
) is not balanced.

Please enter a series of parenthesis to see if they are balanced: ())(()
())(() is not balanced.
Please enter a series of parenthesis to see if they are balanced:
(((())())))
(((())()))) is not balanced.

"""