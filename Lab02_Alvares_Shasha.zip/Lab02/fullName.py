# Author: Shasha Alvares
# Date: 2/3/25
# Description: Ask the user for their first name and last name, using appropriate variable names,
# and outputs it in the format of last name,first name

firstName = input("Please enter your first name: ")
lastName = input("Please enter your last name: ")

print(f"{lastName},{firstName}")
