# Author: Shasha Alvares
# Date: 2/3/25
# Description: Given a duration of time which is chosen by the user, this program computes
# the velocity, average velocity, and displacement of an object.
import math

# Useful values:
acceleration = 5.25
initialVelocity = 8.25

# Initialize the radius:
while True:
    try:
        time = float(input("Please enter the elapsed time: "))
        break
    except ValueError:
        print("Please enter a number. ")

# Calculate the properties (velocity, average velocity, and displacement) of the object:
# Velocity of the object given: 𝑣 = 𝑣0 + 𝑎𝑡
velocity = initialVelocity + acceleration*time

# Average velocity of the object given: 𝑣̅ = 𝑣0 + (1/2)𝑎𝑡
averageVelocity = initialVelocity + (1/2)*acceleration*time

# Displacement of an object given: 𝑥 = 𝑣0(𝑡) + (1/2)𝑎(𝑡^2)
horizontalDisplacement = initialVelocity*time + (1/2)*acceleration*math.pow(time, 2)

# Print the results:
print(f"time = {time}\n")
print(f"velocity \t\t = {velocity}")
print(f"average velocity = {averageVelocity}")
print(f"displacement  \t = {horizontalDisplacement}\n")

