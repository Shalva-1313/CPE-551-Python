# Author: Shasha Alvares
# Date: 2/3/25
# Description: This program computes the slope of a line given 
# the end points of the line. The result is then printed to the screen.

#Corrections made were:
# 1. The syntax of endx and startx was fixed so the "x" was capitalized
# 2. The logic error was fixed such that the denominator was changed to startX - endX
# as per the definition of the slope formula.
# 3. Parenthesis were added to the slope formula to ensure the subtraction occurs first
# in the numerator and denominator and then the division occurs
# 4. The print statements were changed to a print format statements and slope was uncapitalized


# Initialize the end points.
startX = -2
startY = 1
endX = 5
endY = 36

# Compute the slope.
slope = (startY - endY) / (startX - endX)

# Print the results.
print(f"Starting point: ( {startX} , {startY} )")
print(f"Ending point: ( {endX} , {endY} )")
print(f"Slope of the line = {slope}")

