# Author: Shasha Alvares
# Date: 2/24/25
# Description: Graph the hourly temperatures of randomly generated temperatures for three cities

import matplotlib.pyplot as plt
import random

#crete list containing hourly time from 1-12 inclusive
time = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
num_elements = 12 #number of randomly generated temps for each city
legend_labels = ["Hartford", "Boston", "Hoboken"] #City names for graph legend

#create 3 empty lists for cities
hartford = []
boston = []
hoboken = []

#generates 12 temperatures between 10-30 inclusive for each city
for _ in range(num_elements):
    random_int = random.randint(10, 30)
    hartford.append(random_int)
for _ in range(num_elements):
    random_int = random.randint(10, 30)
    boston.append(random_int)
for _ in range(num_elements):
    random_int = random.randint(10, 30)
    hoboken.append(random_int)

# plotting the data
plt.plot(time, hartford)
plt.plot(time, boston)
plt.plot(time, hoboken)

# Adding the title
plt.title("Hourly Temperatures")

# Adding the labels
plt.xlabel("Hours")
plt.ylabel("Temperature")

#Add the legend labels and place legend in center bottom
plt.legend(legend_labels, loc="lower center")
plt.show()