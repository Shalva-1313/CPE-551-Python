# Author: Shasha Alvares
# Date: 1/31/25
# Description: This program outputs the phrase 'Hello World!'

userName = input("Please enter your name: ")
print(f"Hello, {userName}! ")