# Author: Shasha Alvares
# Date: 1/31/25
# Description: This program outputs the phrase 'Hello World!'

print("Hello, World!")