# Author: Shasha Alvares
# Date: 2/24/25
# Description: Simulate an array of CRMD’s on a two-dimensional map, find the two locations with
# the highest and lowest capture rates and output the entire map as a grid.
import random

DIMENSION = 8
exampleMap = []
#variables to store x and y coordinates for the high and low capture rates
xHigh, yHigh, xLow, yLow = 0, 0, 0, 0

#add 0's to each index in the 2D array
for i in range(DIMENSION):
    col = []
    for j in range(DIMENSION):
        col.append(0)
    exampleMap.append(col)

#iterate through the 2D array and add random ints from 0-500 inclusive
for i in range(DIMENSION):
    for j in range(DIMENSION):
        exampleMap[i][j] = random.randint(0, 500)

#variables to store the high and low capture rates. Initially both are set equal
#to the first element in the 2d array
highCapture, lowCapture = exampleMap[0][0], exampleMap[0][0]

#iterate through the 2D array and store largest and smallest capture values
for i in range(DIMENSION):
    for j in range(DIMENSION):
        if exampleMap[i][j] > highCapture:
            highCapture = exampleMap[i][j]
            xHigh, yHigh = i, j
        elif exampleMap[i][j] < lowCapture:
            lowCapture = exampleMap[i][j]
            xLow, yLow = i, j

print(f"The highest capture rate was {highCapture} at location {xHigh+1},{yHigh+1}")
print(f"The lowest capture rate was {lowCapture} at location {xLow+1},{yLow+1}")
print("The map looks like the following: ")

#iterate through the 2D array and print each element
for i in range(DIMENSION):
    for j in range(DIMENSION):
        print(f"{exampleMap[i][j]:4}", end=" ") #print numbers evenly with width 4 between
    print()