# Author: Shasha Alvares
# Date: 4/7/25
# Description: Subclass of employee which additionally stores shift type

from Employee import Employee

class Worker(Employee):
    def __init__(self, name, id, payrate, shiftNum):
        Employee.__init__(self, name, id, payrate)
        self._shiftNum = shiftNum

    def getShift(self):
        return self._shiftNum

    def setShift(self, shiftNum):
        self._shiftNum = shiftNum