# Author: Shasha Alvares
# Date: 4/7/25
# Description: Stores general employee data

class Employee:
    def __init__(self, name, id, payrate):
        self._name = name
        self._id = id
        self._payrate = payrate

    def getName(self):
        return self._name

    def setName(self, name):
        self._name = name

    def getID(self):
        return self._id

    def setID(self, id):
        self._id = id

    def getPayrate(self):
        return self._payrate

    def setPayrate(self, payrate):
        self._payrate = payrate

    def calcPay(self, hoursWorked):
        payscale = hoursWorked * self.getPayrate()
        return payscale
