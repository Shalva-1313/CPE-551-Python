# Author: Shasha Alvares
# Date: 4/7/25
# Description: Subclass of employee which additionally stores level

from Employee import Employee
class Supervisor(Employee):
    def __init__(self, name, id, payrate, level):
        Employee.__init__(self, name, id, payrate)
        self.__level = level #private member

    def getLevel(self):
        return self.__level

    def setLevel(self, level):
        self.__level = level

    # same signature as superclass bc Python only allows overriding
    def calcPay(self, hoursWorked):
        payscale = (hoursWorked * self.getPayrate()) + (1000.0 * self.getLevel())
        return payscale