# Author: Shasha Alvares
# Date: 4/7/25
# Description: Main functino which manages all types of employees of a small company.

from Supervisor import Supervisor
from Worker import Worker

def calcTotalPay(employeeList):
    """ Takes in one List containing both Worker and Supervisor objects and
    calculates and returns the total pay for all employees of the business"""
    totalPay = 0.00
    for employee in employeeList:
        totalPay += employee.calcPay(40) #calcPay will be overridden in the subclass

    print(f"The total cost of all of the worker's pay is ${totalPay:.2f}")

def listEmployees(employeeList):
    """ Takes in one List containing both Worker and Supervisor objects, returns nothing,
    and outputs all of the employee information with appropriate labels using a loop"""
    for person in employeeList:
        if isinstance(person, Supervisor):
            print("Name: " + person.getName())
            print("ID: " + str(person.getID()))
            print(f"Pay Rate: ${person.getPayrate():.2f}")
            print("Level: " + str(person.getLevel()))
        if isinstance(person, Worker):
            print("Name: " + person.getName())
            print("ID: " + str(person.getID()))
            print(f"Pay Rate: ${person.getPayrate():.2f}")
            if person.getShift() == 1:
                print("Shift: Day Shift")
            elif person.getShift() == 2:
                 print("Shift: Night Shift")

def main():
    employeeList = [] #empty list we will store employee objects in
    numEmployeesToAdd = int(input("How many employees would you like to add: "))

    for x in range(numEmployeesToAdd): #prompts user for each employee they want to add

        workerType = input("Would you like to add a worker or a supervisor: ")
        #prompts user until correct input is given
        while workerType.lower().strip() != "supervisor" and workerType.lower().strip() != "worker":
            print(f"{workerType} is not a worker or supervisor. Try again!\n")
            workerType = input("Would you like to add a worker or a supervisor: ")

        #prompts user for supervisor info
        if workerType.lower().strip() == "supervisor":
            name = input("Please enter the name of the supervisor: ")
            idNum = int(input("Please enter the id of the supervisor: "))
            payRateSup = float(input("Please enter the pay rate of the supervisor: "))
            level = int(input("Please enter the level of the supervisor: "))

            #create Supervisor object to add to the list
            exampleSup = Supervisor(name, idNum, payRateSup, level)
            employeeList.append(exampleSup)

        #prompts user for worker info
        elif workerType.lower().strip() == "worker":
            name = input("Please enter the name of the worker: ")
            idNum = int(input("Please enter the id of the worker: "))
            payRateWork = float(input("Please enter the pay rate of the worker: "))
            shiftType = int(input("Please enter the shift of the worker (1 for day, 2 for night): "))

            # create Worker object to append to list
            exampleWorker = Worker(name, idNum, payRateWork, shiftType)
            employeeList.append(exampleWorker)

    #prints list of employees and total pay from all of them summed
    listEmployees(employeeList)
    calcTotalPay(employeeList)

if __name__ == "__main__":
    main()