# Author: Shasha Alvares
# Date: 2/19/25
# Description: Create ascii art based on user's choice of 4 designs
# using characters user inputs for border
import sys

"""
This section of code that was repeated in all 4 of the art functions was AI generated, 
I could not figure out how to properly print the art within the borders so 
I asked AI to help me and studied the code to understand it.  
cat_lines = sleepyCat.strip().split("\n")
    size = max(len(line) for line in cat_lines) + 4 #determine the size with padding for printing the border
    printHeaderFooter(border, size) #print top border
    for line in cat_lines:
        print(f"{border} {line.ljust(size - 3)}{border}") #print each line with size borders
    printHeaderFooter(border, size) #print bottom border
"""
def intro():
    print("Welcome to the painting printer!\n"
          "\tWe have many options:\n"
          "\t1. The S.S. Satisfaction\n"
          "\t2. Mina in Repose\n"
          "\t3. Zelda Logo\n"
          "\t4. Sylvester from Looney Toons\n")

    userPaintChoice = int(input("Please select a painting to print: "))
    userBorderChoice = input("What border would you like around your painting: ")

    return userPaintChoice, userBorderChoice
def printHeaderFooter(border, size):
    print(border * size)

def sleepingCat(border):
    sleepyCat =  """
          |\\      _,,,---,,_
ZZZzz /,`.-'`'    -.  ;-;;,_
     |,4-  ) )-,_. ,\\ (  `'-'
    '---''(_/--'  `-'\\_)"""
    cat_lines = sleepyCat.strip().split("\n")
    size = max(len(line) for line in cat_lines) + 4
    printHeaderFooter(border, size)
    for line in cat_lines:
        print(f"{border} {line.ljust(size - 3)}{border}")
    printHeaderFooter(border, size)

def sailingShip(border):
    sailingShip = """
          |    |    |
     )_)  )_)  )_)
    )___))___))___)\\
   )____)____)_____)\\\\
 _____|____|____|____\\\\\\__
 \\    Satisfaction   /
^^^^^^^^^^^^^^^^^^^^^^^^^^^^ """
    ship_lines = sailingShip.strip().split("\n")
    size = max(len(line) for line in ship_lines) + 4
    printHeaderFooter(border, size)
    for line in ship_lines:
        print(f"{border} {line.ljust(size - 3)}{border}")
    printHeaderFooter(border, size)

def zelda(border):
    specificArt = r"""
                        /@
                     __        __   /\/
                    /==\      /  \_/\/   
                  /======\    \/\__ \__
                /==/\  /\==\    /\_|__ \\
             /==/    ||    \=\ / / / /_/
           /=/    /\ || /\   \=\/ /     
        /===/   /   \||/   \   \===\\
      /===/   /_________________ \===\\
   /====/   / |                /  \====\\
 /====/   /   |  _________    /  \   \===\    THE LEGEND OF 
 /==/   /     | /   /  \ / / /  __________\_____      ______       ___
|===| /       |/   /____/ / /   \   _____ |\   /      \   _ \      \  \\
 \==\             /\   / / /     | |  /= \| | |        | | \ \     / _ \\
 \===\__    \    /  \ / / /   /  | | /===/  | |        | |  \ \   / / \ \\
   \==\ \    \\\\ /____/   /_\ //  | |_____/| | |        | |   | | / /___\ \\
   \===\ \   \\\\\\\/   /////// /|  _____ | | |        | |   | | |  ___  |
     \==\/     \\\\/ / //////   \| |/==/ \| | |        | |   | | | /   \ |
     \==\     _ \\/ / /////    _ | |==/     | |        | |  / /  | |   | |
       \==\  / \ / / ///      /|\| |_____/| | |_____/| | |_/ /   | |   | |
       \==\ /   / / /________/ |/_________|/_________|/_____/   /___\ /___\\
         \==\  /               | /==/
         \=\  /________________|/=/    OCARINA OF TIME
           \==\     _____     /==/ 
          / \===\   \   /   /===/
         / / /\===\  \_/  /===/
        / / /   \====\ /====/
       / / /      \===|===/
       |/_/         \===/
                      = """
    zelda_lines = specificArt.strip().split("\n")
    size = max(len(line) for line in zelda_lines) + 4
    printHeaderFooter(border, size)
    for line in zelda_lines:
        print(f"{border} {line.ljust(size - 3)}{border}")
    printHeaderFooter(border, size)

def sylvester(border):
    specificArt2 = r"""
        / ,
          /\  \|/  /\\
          |\\\\_;=._//|
           \."   "./
           //^\ /^\\\\
    .'``",/ |0| |0| \,"``'.
   /   ,  `'\.---./'`  ,   \\
  /`  /`\,."(     )".,/`\  `\\
  /`     ( '.'-.-'.' )     `\\
  /"`     "._  :  _."     `"\\
   `/.'`"=.,_``=``_,.="`'.\`
             )   ("""
    sylvester_lines = specificArt2.strip().split("\n")
    size = max(len(line) for line in sylvester_lines) + 4
    printHeaderFooter(border, size)
    for line in sylvester_lines:
        print(f"{border} {line.ljust(size - 3)}{border}")
    printHeaderFooter(border, size)

def blank(border):
    size = 7
    printHeaderFooter(border, size)
    for _ in range(5):
        print(f"{border}     {border}")
    printHeaderFooter(border, size)

def main():
    number, border = intro()

    if number == 1:
        sailingShip(border)
    elif number == 2:
        sleepingCat(border)
    elif number == 3:
        zelda(border)
    elif number == 4:
        sylvester(border)
    else:
        blank(border)
        print("Hmmmm....we don't seem to have that painting.")
        exit(-1)

    print("Hope you enjoyed your art!")

if __name__ == "__main__":
    main()
