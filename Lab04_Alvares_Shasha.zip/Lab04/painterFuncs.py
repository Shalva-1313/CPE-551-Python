# Author: Shasha Alvares
# Date: 2/19/25
# Description: Create ascii art based on user's choice of 4 designs
# using characters user inputs for border

"""
This section of code that was repeated in all 4 of the art functions was AI generated,
I could not figure out how to properly print the art within the borders so
I asked AI to help me and studied the code to understand it.
cat_lines = sleepyCat.strip().split("\n")
    size = max(len(line) for line in cat_lines) + 4 #determine the size with padding for printing the border
    printHeaderFooter(border, size) #print top border
    for line in cat_lines:
        print(f"{border} {line.ljust(size - 3)}{border}") #print each line with size borders
    printHeaderFooter(border, size) #print bottom border
"""
def intro():
    """Welcomes user to program and asks what painting and border character they want
    :param none
    :return User's painting and border choice
    """

    print("Welcome to the painting printer!\n"
          "\tWe have many options:\n"
          "\t1. The S.S. Satisfaction\n"
          "\t2. Mina in Repose\n"
          "\t3. Zelda Logo\n"
          "\t4. Sylvester from Looney Toons\n")

    userPaintChoice = int(input("Please select a painting to print: "))
    userBorderChoice = input("What border would you like around your painting: ")

    return userPaintChoice, userBorderChoice
def printHeaderFooter(border, size):
    """Prints the top and bottom borders around the ASCII art
    :param border is the character the user wants the border to be made with
    :type basestring
    :param size is how large the border will be made to fit around the ASCII art
    :type int
    :return the top and bottom borders
    """
    print(border * size)

def sleepingCat(border):
    """Prints the sleeping cat ASCII art
    :param border is the character the user wants the border to be made with
    :type basestring
    :return the cat ASCII art in the border
    """
    sleepyCat =  """
          |\\      _,,,---,,_
ZZZzz /,`.-'`'    -.  ;-;;,_
     |,4-  ) )-,_. ,\\ (  `'-'
    '---''(_/--'  `-'\\_)"""
    cat_lines = sleepyCat.strip().split("\n")
    size = max(len(line) for line in cat_lines) + 4
    printHeaderFooter(border, size)
    for line in cat_lines:
        print(f"{border} {line.ljust(size - 3)}{border}")
    printHeaderFooter(border, size)

def sailingShip(border):
    """Prints the sailing ship ASCII art
    :param border is the character the user wants the border to be made with
    :type basestring
    :return the sailing ship  ASCII art in the border
    """
    sailingShip = """
          |    |    |
     )_)  )_)  )_)
    )___))___))___)\\
   )____)____)_____)\\\\
 _____|____|____|____\\\\\\__
 \\    Satisfaction   /
^^^^^^^^^^^^^^^^^^^^^^^^^^^^ """
    ship_lines = sailingShip.strip().split("\n")
    size = max(len(line) for line in ship_lines) + 4
    printHeaderFooter(border, size)
    for line in ship_lines:
        print(f"{border} {line.ljust(size - 3)}{border}")
    printHeaderFooter(border, size)

def zelda(border):
    """Prints the zelda ASCII art
    :param border is the character the user wants the border to be made with
    :type basestring
    :return the zelda  ASCII art in the border
    """
    specificArt = r"""
                        /@
                     __        __   /\/
                    /==\      /  \_/\/   
                  /======\    \/\__ \__
                /==/\  /\==\    /\_|__ \\
             /==/    ||    \=\ / / / /_/
           /=/    /\ || /\   \=\/ /     
        /===/   /   \||/   \   \===\\
      /===/   /_________________ \===\\
   /====/   / |                /  \====\\
 /====/   /   |  _________    /  \   \===\    THE LEGEND OF 
 /==/   /     | /   /  \ / / /  __________\_____      ______       ___
|===| /       |/   /____/ / /   \   _____ |\   /      \   _ \      \  \\
 \==\             /\   / / /     | |  /= \| | |        | | \ \     / _ \\
 \===\__    \    /  \ / / /   /  | | /===/  | |        | |  \ \   / / \ \\
   \==\ \    \\\\ /____/   /_\ //  | |_____/| | |        | |   | | / /___\ \\
   \===\ \   \\\\\\\/   /////// /|  _____ | | |        | |   | | |  ___  |
     \==\/     \\\\/ / //////   \| |/==/ \| | |        | |   | | | /   \ |
     \==\     _ \\/ / /////    _ | |==/     | |        | |  / /  | |   | |
       \==\  / \ / / ///      /|\| |_____/| | |_____/| | |_/ /   | |   | |
       \==\ /   / / /________/ |/_________|/_________|/_____/   /___\ /___\\
         \==\  /               | /==/
         \=\  /________________|/=/    OCARINA OF TIME
           \==\     _____     /==/ 
          / \===\   \   /   /===/
         / / /\===\  \_/  /===/
        / / /   \====\ /====/
       / / /      \===|===/
       |/_/         \===/
                      = """
    zelda_lines = specificArt.strip().split("\n")
    size = max(len(line) for line in zelda_lines) + 4
    printHeaderFooter(border, size)
    for line in zelda_lines:
        print(f"{border} {line.ljust(size - 3)}{border}")
    printHeaderFooter(border, size)

def sylvester(border):
    """Prints the sylvester ASCII art
    :param border is the character the user wants the border to be made with
    :type basestring
    :return the sylvester ASCII art in the border
    """

    specificArt2 = r"""
        / ,
          /\  \|/  /\\
          |\\\\_;=._//|
           \."   "./
           //^\ /^\\\\
    .'``",/ |0| |0| \,"``'.
   /   ,  `'\.---./'`  ,   \\
  /`  /`\,."(     )".,/`\  `\\
  /`     ( '.'-.-'.' )     `\\
  /"`     "._  :  _."     `"\\
   `/.'`"=.,_``=``_,.="`'.\`
             )   ("""
    sylvester_lines = specificArt2.strip().split("\n")
    size = max(len(line) for line in sylvester_lines) + 4
    printHeaderFooter(border, size)
    for line in sylvester_lines:
        print(f"{border} {line.ljust(size - 3)}{border}")
    printHeaderFooter(border, size)

def blank(border):
    """Prints an empty portrait if the user does not select a painting 1-4
        :param border is the character the user wants the border to be made with
        :type basestring
        :return empty portrait string
        """
    size = 7
    printHeaderFooter(border, size)
    for _ in range(5):
        print(f"{border}     {border}")
    printHeaderFooter(border, size)
