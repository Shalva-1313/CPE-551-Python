# Author: Shasha Alvares
# Date: 2/19/25
# Description: Create ascii art based on user's choice of 4 designs
# using characters user inputs for border

import painterFuncs
def main():
    number, border = painterFuncs.intro()

    if number == 1:
        painterFuncs.sailingShip(border)
    elif number == 2:
        painterFuncs.sleepingCat(border)
    elif number == 3:
        painterFuncs.zelda(border)
    elif number == 4:
        painterFuncs.sylvester(border)
    else:
        painterFuncs.blank(border)
        print("Hmmmm....we don't seem to have that painting.")
        exit(-1)

    print("Hope you enjoyed your art!")

if __name__ == "__main__":
    main()