# Author: Shasha Alvares
# Date: 2/19/25
# Description: Calculates the surface area of a pyramid given the side and height as inputs
import math

# function definitions
def calcBaseArea(side):
    return side ** 2

# add your function definition for calcSideArea here
def calcSideArea(side, height):
    sum = (2*side) * math.sqrt((side**2)/4 + height**2)
    return sum

# add your function definition for prntSurfArea here
def prntSurfArea(base, totalSides):
    print(f"The total surface area of the square pyramid is {base+totalSides} square feet")

def main():
    side = float(input("Enter the side length of the base of the square pyramid in feet: "))

    height = float(input("Enter the height of the square pyramid in feet: "))

    base_area = calcBaseArea(side)
    print(f"Base surface area of the square pyramid is {base_area} square feet.")

    # add your function to calculate the side area and assign
    # the result to side_area, then print the result
    side_area = calcSideArea(side, height)
    print(f"Side surface area of the square pyramid is {side_area} square feet.")

    # add your function call to print the total surface area
    prntSurfArea(base_area,side_area)


if __name__ == "__main__":
    main()