import pytest
import pyramidArea

def test_calcBaseArea_works():
    result = pyramidArea.calcBaseArea(15)
    assert result == 225

@pytest.mark.xfail(reason="Input should not be text!")
def test_calcBaseArea_fail():
    result = pyramidArea.calcBaseArea('5')

def test_calcSideArea_works():
    result = pyramidArea.calcSideArea(15, 5)
    assert 270.41 < result < 270.42

def test_calcSideArea_precise():
    result = pyramidArea.calcSideArea(10, 3)
    result = round(result,2)
    assert result == 116.62

@pytest.mark.skip(reason="Function only prints text to screen")
def test_prntSurfArea():
    result = pyramidArea.calcBaseArea(5)