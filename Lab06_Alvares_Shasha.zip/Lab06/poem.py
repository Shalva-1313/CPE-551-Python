# Author: Shasha Alvares
# Date: 3/7/25
# Description: Read in a poem, store the information, and then write a short
# summary of the poem to another file.
import os

def main():
    #keep prompting the user until they enter a file that exists
    while True:
        userFile = input("Please input the name of the poem you wish summarized: ")
        if os.path.exists(userFile):
            break
        print("Snowball does not exist! ", end="")

    with (open("Snowball.txt", "r") as myFile):
        List = []
        first_line = myFile.readline().strip()      #poem's title
        second_line = myFile.readline().strip()     #author's name
        poem_file_name = 'Snowball.txt'             #name of file poem is in

        List = myFile.read().strip().split("\n")
        poem_size = len(List)

    with(open("Output.txt", 'w') as myOutputFile):
        print("The name of the poem is", first_line)
        print("The author of the poem is", second_line)
        print("The number of lines in the poem is", poem_size)
        print("A preview of the poem is:")
        print(List[0] + '\n' + List[1] + '\n' + List[2])

if __name__ == "__main__":
    main()