import pbnFunctions
# Author: Shasha Alvares
# Date: 3/7/25
# Description: Creates ascii art and writes it to a new file based on the input csv file.

def main():
    fileName = pbnFunctions.getFileName()   #keep prompting the user until they enter a csv file that exists
    pbnFunctions.processFile(fileName)      #opens fileName to read from and writes ascii art to new painting.txt file
    print("Your image can be found in painting.txt . Enjoy!")

if __name__ == "__main__":
    main()