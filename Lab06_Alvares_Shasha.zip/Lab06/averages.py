# Author: Shasha Alvares
# Date: 3/7/25
# Description: Read in numbers.txt file and compute and print
# the average of the numbers in the txt file

def main():
    with open("numbers.txt", "r") as myFile:
        summ = 0                                #Keep track of the sum of all numbers in the .txt file
        count = 0                               #Keep track of the total numbers in the .txt file
        for line in myFile:
            line = int(line.strip())            #Remove newline and convert line from a string to int
            print(line)                         #Print each number from the .txt file to the screen
            summ = summ + line                  #Calculate sum of all the integers
            count = count + 1                   #Calculate how many numbers are in the .txt file
        print("The average of the numbers is", summ/count)                       #Print the average of the numbers in the .txt file


if __name__ == "__main__":
    main()