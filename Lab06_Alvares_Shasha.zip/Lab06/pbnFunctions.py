import os

def getFileName():
    """Continually re-prompt the user until they enter a csv filename that exists
    :param none
    :return file name """
    while True:
        userFile = input("Please input file you wish to have painted: ")
        if os.path.exists(userFile) and userFile.endswith(".csv"):
            return userFile
        print("image does not exist! ", end="")

def convertLine(line):
    """Converts and returns each line from the input file to corresponding ascii line
    :param line from input file
    :return line converted from numbers to ascii art """
    newLine = ""                                #create an empty string to store the converted line
    aline = line.strip().split(",")             #split the line into a list if numbers
    for num in aline:                           #replace every number with the corresponding symbol
        if num == "1":
            newLine += num.replace("1", " ")
        elif num  == "2":
            newLine += num.replace("2", ",")
        elif num  == "3":
            newLine += num.replace("3", "_")
        elif num  == "4":
            newLine += num.replace("4", "(")
        elif num == "5":
            newLine += num.replace("5", "O")
        elif num == "6":
            newLine += num.replace("6", ")")
        elif num == "7":
            newLine += num.replace("7", "-")
        elif num == "8":
            newLine += num.replace("8", "\"")
    return newLine                                      #return the ascii art converted line

def processFile(filename):
    """Opens input file and writes each converted ascii line to a new file
    :param input file
    :return output file of ascii art """
    with open(filename, "r") as myFile:                 #reads from input file and writes to output
        with open("painting.txt", "w") as paintFile:
            for line in myFile:
                newLine = convertLine(line)             #converts and returns input line as ascii art line
                paintFile.write(newLine + "\n")         #writes each ascii art line to the new file

